package ThreadExample;

public class ThreadLifeCycle implements Runnable{

	public void run() {
		System.out.println("Thread running...");
	}
	public static void main(String[] args) throws InterruptedException {
		Thread t = new Thread(new ThreadLifeCycle());
		
		System.out.println("State before start: " + t.getState()); //NEW
		t.start();
		
		System.out.println("State after start: " + t.getState()); //RUNNABLE
		Thread.sleep(1000);
		
		
		System.out.println("State after sleep: " + t.getState()); //TERMINATED

	}

}

/*
 3. Thread Lifecycle

States:

New
Runnable
Running
Waiting
Terminated
 */
