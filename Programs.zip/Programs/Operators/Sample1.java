package Operators;

public class Sample1 {

	public static void main(String[] args) {
		Sample1 s = new Sample1();
		System.out.println(s instanceof Sample1);
	}

}
