package Operators;

public class Conditional {

	public static void main(String[] args) {
		int a , b;
		a=10;
		b = (a==1)?20:30; //a==1 - false  b=30
		System.out.println("Value of b is : "+b);
		b = (a==10)?20:30; //a==10 - true = b=20 
		System.out.println("Value of b is : "+b);
	}

}
