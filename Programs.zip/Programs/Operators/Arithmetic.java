package Operators;

public class Arithmetic {

	public static void main(String[] args) {
		int a = 10, b=20, c=25, d=25;
		System.out.println("a+b = "+(a+b)); //BODMAS - Addition = 30
		System.out.println("a-b = "+(a-b)); //Substraction = 10-20 = -10
		System.out.println("a*b = "+(a*b)); //Multiplication = 10*20 = 200
		System.out.println("a/b = "+(a/b)); //Division    = 10/20 = 0
		System.out.println("b%a = "+(b%a)); //Modulus     = 20%10 = 0
		System.out.println("c++ = "+(c++)); //Increment   = 25++ = 25
		System.out.println("c-- = "+(c--)); //Decrement   = 26-- = 26
		System.out.println("c = "+c); //c=25
		
		//pre increment and decrement
		System.out.println("--d = "+(--d)); //--25 = --24
		System.out.println("++d = "+(++d)); //++24 = 25
	}

}
