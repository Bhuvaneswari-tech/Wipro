package Class_Objects;

public class prg1 {

	int prod_id=101;  //instance variable
	String productName = "Wireless Router";  //instance variable
	
	public void display() {
		float price = 1599;  //Local Variable
		System.out.println("Product Id: "+prod_id);
		System.out.println("Product Name: "+productName);
		System.out.println("Product price: "+price);
	}
	
	public static void main(String[] args) {
		prg1 p1 = new prg1(); //Object creation
		p1.display();
		System.out.println(p1.prod_id);
		System.out.println(p1.productName);
		//System.out.println(p1.price);

	}

}
