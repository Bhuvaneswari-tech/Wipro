package Class_Objects;

public class Student {
	
	int rollno;  //instance variable
	String name;
	static String college = "ABC Univesity";  // static variable / class variable
	 
	//constructor
	Student(int r, String n){
		rollno = r;
		name = n;
	}
	
	void display() {
		System.out.println("Student details: ");
		System.out.println(rollno+ " "+name+" "+college);
	}

	public static void main(String[] args) {
		Student s1 = new Student(111,"Rakesh");
		Student s2 = new Student(222,"Praveen");
		s1.display();
		s2.display();
		System.out.println(college);
	}
}


/*
 Constructor - class name and method name are same
 usage - for initilizing the values
 */