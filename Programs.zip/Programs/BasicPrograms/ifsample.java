package BasicPrograms;

public class ifsample {

	public static void main(String[] args) {
		int x=10,y=20;
		if(x<y)
			System.out.println("x is lesser than y");
		else if(x>y) {
			System.out.println("x is greater than y");
		}
		else if(x==y)
			System.out.println("x is equal to y");
//		if(x!=y)
//			System.out.println("x is not equal to y");
			
	}

}
