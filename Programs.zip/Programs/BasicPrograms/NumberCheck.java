package BasicPrograms;

import java.util.Scanner;

public class NumberCheck {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int num = s.nextInt();
		if(num>0) {
			System.out.println("Number is Positive");
		}
		else if(num<0)
			System.out.println("Number is Negative");
		else
			System.out.println("Zero");
		s.close();
	}

}

