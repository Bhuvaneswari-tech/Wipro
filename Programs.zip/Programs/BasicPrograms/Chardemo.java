package BasicPrograms;

public class Chardemo {

	public static void main(String[] args) {
		//char ch1='X';
		char ch1 = 88; //ascii code for X
		System.out.println("ch1 contains: "+ch1);
		ch1++;
		System.out.println("ch1 now: "+ch1);

	}

}
