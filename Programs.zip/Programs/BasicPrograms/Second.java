package BasicPrograms;

public class Second {

	public static void main(String[] args) {
		int num;   //variable declaration
		int num1 = 100; //Java literals
		num = 200; //variable assigning
		
		int output = num+num1;
		
		System.out.println("Result: "+output);  //sysout - ctrl+space
		System.out.printf("Result: %d", output);

	}

}
