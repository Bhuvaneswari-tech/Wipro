package BasicPrograms;

import java.util.Scanner;

public class SwitchSample {

	public static void main(String[] args) {
		Scanner s =  new Scanner(System.in);
		System.out.print("Enter the grade: ");
		char ch = s.next().charAt(0);
		switch(ch) {
		case 'A' | 'a':
			System.out.println("Excellent!");
			break;
		case 'B' | 'b':
			System.out.println("Well done");
			break;
		case 'C' | 'c':
			System.out.println("You have passed");
			break;
		case 'D' | 'd':
			System.out.println("Better try again");
			break;
		default:
			System.out.println("Invalid grade");
		}
		System.out.println("Your grade is: "+ch);
		s.close();
	}

}
