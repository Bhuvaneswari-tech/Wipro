package BasicPrograms;

public class Average {

	public static void main(String[] args) {
		int sum=0,avg;
		int arr[]= {1,2,3,4,5};  //arr[0]=1, arr[1]=2
		for(int i=0;i<arr.length;i++) {
			sum = sum + arr[i];
		}
		avg = sum/arr.length;
		System.out.println("Sum: "+sum);
		System.out.println("Average: "+avg);
	}

}
