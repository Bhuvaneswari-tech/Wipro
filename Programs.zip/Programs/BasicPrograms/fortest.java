package BasicPrograms;

public class fortest {

	public static void main(String[] args) {
		//int x;
		for(int x=0;x<10;x++) {
			System.out.println("This is x: "+x);
		}

	}

}
