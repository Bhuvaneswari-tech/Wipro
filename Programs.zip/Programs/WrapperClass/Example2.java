package WrapperClass;

public class Example2 {

	public static void main(String[] args) {
		char c = 'A';
		if(Character.isLetter(c))
			System.out.println(c + " is a letter");
		else
			System.out.println(c + " is a digit");

	}

}
