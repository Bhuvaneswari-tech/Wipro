package StringProgram;

public class StringAPIExample {

	public static void main(String[] args) {
		String text = "   Java Programming Language   ";
		
		System.out.println("Original: '" + text + "'");
        System.out.println("Length: " + text.length());
        System.out.println("Trimmed: '" + text.trim() + "'");
        System.out.println("Lowercase: " + text.toLowerCase());
        System.out.println("Uppercase: " + text.toUpperCase());
        System.out.println("Substring (5 to 16): " + text.substring(5, 16));
        System.out.println("Starts with 'Java'? " + text.trim().startsWith("Java"));
        System.out.println("Contains 'gram'? " + text.contains("gram"));

	}

}
