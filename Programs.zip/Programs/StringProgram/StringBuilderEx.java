package StringProgram;

public class StringBuilderEx {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("Java");
        sb.append(" Programming");
        sb.insert(0, "Welcome to ");
        sb.replace(11, 15, "Awesome");
        sb.reverse();
        sb.reverse();  // To restore original
        System.out.println("Final String: " + sb.toString());

	}

}
