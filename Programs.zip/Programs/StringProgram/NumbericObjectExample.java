package StringProgram;

public class NumbericObjectExample {

	public static void main(String[] args) {
		//Integer class method
		Integer x = Integer.valueOf(100);
        Integer a = 25;
        Integer b = 50;

        System.out.println("Integer Value: " + x);
        System.out.println("Integer.compare(a, b): " + Integer.compare(a, b));
        System.out.println("Integer.bitCount(x): " + Integer.bitCount(x));
        System.out.println("Integer.toBinaryString(x): " + Integer.toBinaryString(x));
      //  System.out.println("Integer.reverse(x): " + Integer.reverse(x));
        
        Double y = Double.parseDouble("45.67");
        Double d1 = 45.67;
        Double d2 = 23.45;
        
        System.out.println("\nDouble Value: " + y);
        System.out.println("Double.compare(d1, d2): " + Double.compare(d1, d2));
        System.out.println("Double.isNaN(d1): " + Double.isNaN(d1));

        //Math class methods
        System.out.println("\nMath.max(x,y): "+Math.max(x, y));
        System.out.println("Math.sqrt(x): "+Math.sqrt(x));
        System.out.println("Math.round(y): " + Math.round(y));
        System.out.println("Math.random(): " + Math.random());
        System.out.println("Math.pow(a, 2): " + Math.pow(a, 2));
	}

}

/*
100 ÷ 2 = 50 remainder 0
50 ÷ 2 = 25 remainder 0
25 ÷ 2 = 12 remainder 1
12 ÷ 2 = 6 remainder 0
6 ÷ 2 = 3 remainder 0
3 ÷ 2 = 1 remainder 1
1 ÷ 2 = 0 remainder 1 

. Binary of 100:

100 in 32-bit binary:

00000000 00000000 00000000 01100100
2. Reverse the bits:

Flip the bit order from left to right:

00100110 00000000 00000000 00000000

 */
