package StringProgram;

public class String_Buffer {

	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer("Hello");
		sb.append(" World");
		System.out.println("String Buffer Output: "+sb);
	}

}
