package StringProgram;

public class Concatenator {

	public static void main(String[] args) {
		String first="Hello";
		String second = "World";
		String result = first + " " + second;
		System.out.println("Concatenated String: "+result);
	}

}
