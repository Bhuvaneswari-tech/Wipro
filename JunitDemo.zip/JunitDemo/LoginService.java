package JunitDemo;

public class LoginService {
	public boolean authenticate(String username, String password) {
		return "user".equals(username) && "pass".equals(password);
	}
	public boolean isUsernameValid(String username) {
		return username!=null && username.length() >=4;
	}
}

/*
 
 first method
 input - user , pass - testcase passes
 second method
 admin - pass 
*/