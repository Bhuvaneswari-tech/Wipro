package JunitDemo;

public class MessageSender {

	public String send(String to, String message) {
		return "Sending '" +message +"' to" + to;
	}
}
