package JunitDemo;

public class Student {
	private String name;
	private boolean enrolled;

	public Student(String name) {
		this.name = name;
		this.enrolled = false;
	}
	
	public void enroll() {
		this.enrolled = true;
	}
	
	public boolean isEnrolled() {
		return enrolled;
	}
	
	public String getName() {
		return name;
	}
	
	
}
