package JunitDemo;

public class NumberUtil {
	public static boolean isEven(int number) {
		return number % 2 == 0;
	}
}
