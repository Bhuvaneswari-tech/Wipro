package JunitDemo;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class LoginServiceTest {
	
	LoginService ls = new LoginService();
	
	@Test
	void testAuthenticateSuccess() {
		assertTrue(ls.authenticate("user", "pass"),"Authenticated Login Successful.");
	}
	
	@Test
	void testAuthenticateFailure() {
		assertFalse(ls.authenticate("user", "pass123"),"Not Authenticated. Invalid username or Password.");
	}
	
	@Test
	void testAuthticateWithNullValues() {
		assertFalse(ls.authenticate(null, null),"Not Authenticated. Username and password should not be null.");
	}
	
	@Test
    void testAuthenticateWithEmptyStrings() {
        assertFalse(ls.authenticate("", ""),"Not Authenticated. Username and password should not be emptry strings.");
    }
	
	@Test
    void testValidUsername() {
        assertTrue(ls.isUsernameValid("john"),"Valid Username.");
    }

    @Test
    void testUsernameTooShort() {
        assertFalse(ls.isUsernameValid("abc"),"Username is too Short");
    }

    @Test
    void testUsernameNull() {
        assertFalse(ls.isUsernameValid(null),"Username should not be null.");
    }

    @Test
    void testUsernameExactlyFourCharacters() {
        assertTrue(ls.isUsernameValid("abcd"),"Valid Username.");
    }

    @Test
    void testUsernameWithWhitespace() {
        assertTrue(ls.isUsernameValid("    "),"Usernane should not contain White spaces");  // Still 4 characters
    }

}
