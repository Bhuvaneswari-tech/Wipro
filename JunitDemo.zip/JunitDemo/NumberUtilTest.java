package JunitDemo;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class NumberUtilTest {
	
	@ParameterizedTest
	@ValueSource(ints = {2,4,6,8,10,100})
	void testIsEven_withEvenNumbers(int input) {
		assertTrue(NumberUtil.isEven(input));
	}
	
	@ParameterizedTest
	@ValueSource(ints = {1,3,7,11,17})
	void testIsEven_withOddNumbers(int input) {
		assertFalse(NumberUtil.isEven(input));
	}

}
