package JunitDemo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class ProductTest {
	@Test
	void testApplyValidDiscount() {
		Product prod = new Product("Laptop", 1000.0,5, 10);
		prod.applyDiscount(10);
		assertEquals(10.0, prod.getDiscountPercentage());
		
	}
	
	@Test
	void testApplyInvalidDiscount() {
		Product prod = new Product("Laptop", 1000.0,5, 10);
		//prod.applyDiscount(120);
		assertThrows(IllegalArgumentException.class, () -> prod.applyDiscount(120));
	}
	
	@Test
	void testDiscountPriceWithZeroDiscount() {
		Product prod = new Product("Laptop", 500.0,5, 10);
		prod.applyDiscount(0.0);
		assertEquals(500.0,prod.getDiscountPrice(),0.01); //500.00000001 = 500.00 
	}
	
	 @Test
	    void testDiscountPriceWith100Percent() {
	        Product product = new Product("Phone", 500.0, 5, 5);
	        product.applyDiscount(100.0);
	        assertEquals(0.0, product.getDiscountPrice(), 0.01);
	    }
	 
	 @Test
	 void testSuccessfulPurchase() {
		 Product product = new Product("Tablet", 2000.0, 10, 7);
		 assertTrue(product.purchase(5));
		 assertEquals(5,product.getStock());
	 }
	 
	 @Test
	    void testPurchaseMoreThanStock() {
	        Product product = new Product("Tablet", 200.0, 3, 10);
	        assertFalse(product.purchase(5));
	    }
	 
	 @Test
	    void testValidRestock() {
	        Product product = new Product("Camera", 1500.0, 2, 10);
	        product.restock(5);
	        assertEquals(7, product.getStock());
	    }
	 
	 @Test
	    void testRestockWithNegativeQuantity() {
	        Product product = new Product("Camera", 1500.0, 2, 20);
	        assertThrows(IllegalArgumentException.class, () -> product.restock(-3));
	    }
	 
	 
}
