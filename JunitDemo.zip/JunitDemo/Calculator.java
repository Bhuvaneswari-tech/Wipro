package JunitDemo;

public class Calculator {
	public int add(int a, int b) {
        return a + b;
    }

    public int substract(int a, int b) {
        return a - b;
    }
}


//4 methods
//add(), substract(), multiple(), divide()
//for each method need assertTrue and assertFalse test cases.
//add - 2 test cases - testAddSuccess - assertTrue, testAddFailure - assertFales
//Total testcases - 8 test cases.