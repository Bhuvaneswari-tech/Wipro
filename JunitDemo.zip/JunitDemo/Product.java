package JunitDemo;

public class Product {
	private String name;
	private double price;
	private int stock;
	private double discountPercentage;
	public Product(String name, double price, int stock, double discountPercentage) {
		this.name = name;
		this.price = price;
		this.stock = stock;
		this.discountPercentage = discountPercentage;
	}
	
	//Method1: Apply discount
	public void applyDiscount(double discount) {
		if(discount<0 || discount>100) {
			throw new IllegalArgumentException("Discount must be between 0 and 100.");
		}
		this.discountPercentage = discount;
	}
	
	//Method2: Get price after discount
	public double getDiscountPrice() {
		return price - (price * discountPercentage/100);
	}
	
	//Method3: Purchase product
	public boolean purchase(int quantity) {
		if(quantity<0) return false;
		if(quantity > stock) return false;
		stock = stock - quantity;
		return true;
	}
	
	//Method4: Restock PRoduct
	public void restock(int quantity) {
		if(quantity<= 0) throw new IllegalArgumentException("Quantity must be positive");
		stock += quantity;
	}

	public String getName() {
		return name;
	}

	public double getPrice() {
		return price;
	}

	public int getStock() {
		return stock;
	}

	public double getDiscountPercentage() {
		return discountPercentage;
	}
	
}
