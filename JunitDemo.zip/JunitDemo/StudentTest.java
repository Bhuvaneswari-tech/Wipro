package JunitDemo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class StudentTest {
	
	Student stud;

	@Test
	void testStudentEnrollment() {
		stud = new Student("Alice");
		stud.enroll();
		assertTrue(stud.isEnrolled());
		System.out.println("Enrolled Student");
	}
	
	@Test
	void testStudentStudentName() {
		stud = new Student("Charlie");
		assertEquals("Charlie", stud.getName());
		System.out.println("Student name retrieved");
	}

}
