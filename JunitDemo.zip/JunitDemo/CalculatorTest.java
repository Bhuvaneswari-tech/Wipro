package JunitDemo;

import static org.junit.jupiter.api.Assertions.assertEquals;

//import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

public class CalculatorTest {

	@Test
	public void testAdd() {
		Calculator calc = new Calculator();
		//assertEquals(10,calc.add(6, 4));
		assertEquals(10, calc.add(6, 4));
	    assertEquals(15, calc.add(10, 5));
	    assertEquals(0, calc.add(0, 0));
	}
	
	@Test
	public void testSubstract() {
		Calculator calc = new Calculator();
		//assertEquals(2,calc.substract(6, 4));
		assertEquals(-10, calc.add(-6, -4));
	    assertEquals(0, calc.add(-5, 5));
	}
}
