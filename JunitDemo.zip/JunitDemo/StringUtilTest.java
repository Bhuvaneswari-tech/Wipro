package JunitDemo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

public class StringUtilTest {
	@Test
	void testCapitalizeNormalString() {
		StringUtil su = new StringUtil();
		String result = su.capitalize("hello");
		assertEquals("Hello",result,"Capitalizing 'hello' should result in 'Hello'");
	}
	
	@Test
	void testCapitalizeNullString() {
		StringUtil su = new StringUtil();
		String result = su.capitalize(null);
		assertNull(result,"Capitalizing null should result in null");
	}
}
