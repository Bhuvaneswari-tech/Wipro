package JunitDemo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;

public class MessageTest {

	@Test
	public void testNotifyUser(){
	MessageSender mockSender = mock(MessageSender.class);
	
	when(mockSender.send("Alice", "Hello from Mockito!"))
		.thenReturn("Mock message sent to Alice");
	
	
	//Inject mock into Messenger
	Messenger messenger = new Messenger(mockSender);
	
	//Call method and assert
	String compare = messenger.notifyUser("Alice");
	assertEquals("Mock message sent to Alice", compare);
	
	//Verify interaction
	verify(mockSender).send("Alice", "Hello from Mockito!");
	}
	
}
