package JunitDemo;

public class DatabaseConnection {
	public void connect() {
		System.out.println("Connected to database.");
	}
	
	public void disconnect() {
		System.out.println("Disconnected to database.");
	}
	public boolean isConnected(){
		return true;
	}
}
