package JunitDemo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class CourseTest {

	Course course;
	
	@Test
	void testCourseIsLong() {
		course = new Course("Java Programming", 50);
		assertTrue(course.isLongCourse());
	}
	
	@Test
	void testCourseTitle() {
		course = new Course("Data Structures", 35);
		assertEquals("Data Structures", course.getTitle());
	}
}
