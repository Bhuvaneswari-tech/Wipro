package JunitDemo;

public class Messenger {
	private MessageSender sender;

	public Messenger(MessageSender sender) {
		this.sender = sender;
	}
	
	public String notifyUser(String user) {
		return sender.send(user, "Hello from Mockito!");
	}
}
