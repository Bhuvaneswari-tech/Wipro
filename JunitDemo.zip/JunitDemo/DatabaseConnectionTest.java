package JunitDemo;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class DatabaseConnectionTest {
	
	DatabaseConnection db;
	
	@BeforeAll
	void globalSetup() {
		System.out.println("BeforeAll: Global test setup.");
	}
	
	@AfterAll
	void globalTearDown() {
		System.out.println("AfterAll: Global test cleanup.");
	}
	
	@BeforeEach
	void setup() {
		db = new DatabaseConnection();
		db.connect();
		System.out.println("BeforeEach: Connected.");
	}
	
	@AfterEach
	void tearDown() {
		db.disconnect();
		System.out.println("AfterEach: Disconnected.");
	}
	
	@Test
	void testIsConnectedReturnsTrue() {
		assertTrue(db.isConnected());
		System.out.println("Test1 executed.");
	}
	
	@Test
	void testAnotherConnectionScenario() {
		assertNotNull(db);
		System.out.println("Test2 executed");
	}

}
